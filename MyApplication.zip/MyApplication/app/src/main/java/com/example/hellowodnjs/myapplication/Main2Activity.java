package com.example.hellowodnjs.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.hellowodnjs.R;
import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.hellowodnjs.R;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class Main2Activity extends Activity {

    long seed = System.nanoTime();
    List<ImageButton> buttonList = new ArrayList<ImageButton>();
    List<Integer> imageBackgroundSources = new ArrayList<Integer>();
    List<Integer> widgetIds = new ArrayList<Integer>();
    List<Main2Activity.CustomButton> CustomButtons = new ArrayList<Main2Activity.CustomButton>();
    List<MediaPlayer> mediaPlayers = new ArrayList<MediaPlayer>();
    int count;
    int matchnum;
    TextView ev;
    Main2Activity.CustomButton previousButton;
    Main2Activity.CustomButton currentButton;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        if (savedInstanceState != null) {
            // Restore value of members from saved state
            // count = savedInstanceState.getInt("countKey");
        } else {
            this.initPlay();
            this.startPlay();
            ImageButton startPlaybutton = (ImageButton) findViewById(R.id.playButton);
            Button.OnClickListener startPlayListener = new Button.OnClickListener() {
                public void onClick(View dummy) {
                    startPlay();
                    matchnum = 0;
                }
            };
            startPlaybutton.setOnClickListener(startPlayListener);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle state) {
        state.putInt("countKey", count);
        super.onSaveInstanceState(state);
    }

    public void initPlay() {

        // Initialize Buttons, allocate random images for each button.
        imageBackgroundSources.add(R.drawable.minion2);
        imageBackgroundSources.add(R.drawable.minion4);
        imageBackgroundSources.add(R.drawable.minion5);
        imageBackgroundSources.add(R.drawable.minion22);
        imageBackgroundSources.add(R.drawable.minion23);
        imageBackgroundSources.add(R.drawable.minion24);
        imageBackgroundSources.add(R.drawable.minion25);
        imageBackgroundSources.add(R.drawable.minion31);

        mediaPlayers.add(MediaPlayer.create(Main2Activity.this, R.raw.elo));
        mediaPlayers.add(MediaPlayer.create(Main2Activity.this, R.raw.banana));
        mediaPlayers.add(MediaPlayer.create(Main2Activity.this, R.raw.laugh));
        mediaPlayers.add(MediaPlayer.create(Main2Activity.this, R.raw.hmmm));
        mediaPlayers.add(MediaPlayer.create(Main2Activity.this, R.raw.paput));
        mediaPlayers.add(MediaPlayer.create(Main2Activity.this, R.raw.what));
        mediaPlayers.add(MediaPlayer.create(Main2Activity.this, R.raw.woohaha));
        mediaPlayers.add(MediaPlayer.create(Main2Activity.this, R.raw.paratu));

        widgetIds.add(R.id.imageButton0);
        widgetIds.add(R.id.imageButton1);
        widgetIds.add(R.id.imageButton2);
        widgetIds.add(R.id.imageButton3);
        widgetIds.add(R.id.imageButton4);
        widgetIds.add(R.id.imageButton5);
        widgetIds.add(R.id.imageButton6);
        widgetIds.add(R.id.imageButton7);
        widgetIds.add(R.id.imageButton8);
        widgetIds.add(R.id.imageButton9);
        widgetIds.add(R.id.imageButton10);
        widgetIds.add(R.id.imageButton11);

    }

    public void startPlay() {
        count = 0;
        CustomButtons.clear();
        previousButton = null;
        Collections.shuffle(widgetIds, new Random(seed));
        for (int i = 0; i < 12; i++) {
            Main2Activity.CustomButton button1 = new Main2Activity.CustomButton(i, widgetIds.get(i));
            CustomButtons.add(button1);
        }

        ev = (TextView) findViewById(R.id.textView1);
        ev.setText("0");
    }

    class CustomButton {
        int id;
        int imageBackgroundSource;
        ImageButton button;
        boolean matched;
        MediaPlayer mp;

        public CustomButton(int n, int widgetId) {
            matched = false;
            if (n >= 6)
                this.id = n - 6;
            else
                this.id = n;
            imageBackgroundSource = imageBackgroundSources.get(id);
            mp = mediaPlayers.get(id);
            button = (ImageButton) findViewById(widgetId);
            Log.d("Buttongroup", String.valueOf(this.id));
            button.setVisibility(View.VISIBLE);
            this.turnFaceDown();

            Button.OnClickListener listener = new Button.OnClickListener() {
                public void onClick(View dummy) {
                    if (previousButton == null)
                        count++;
                    if ((previousButton != null)
                            && !(previousButton.getButton() == button)) {
                        count++;
                        if(count == 30){
                            Toast.makeText(Main2Activity.this, "아깝네요ㅠㅠ 다시 도전!", Toast.LENGTH_LONG).show();
                            Intent intent = new Intent(Main2Activity.this, Main2Activity.class);
                            startActivity(intent);
                        }
                        if (previousButton.equals(Main2Activity.CustomButton.this)) {
                            previousButton.setMatch();
                            previousButton.turnFaceUp();
                            setMatch();
                            matchnum++;
                            if(matchnum == 6 )
                            {
                                Toast.makeText(Main2Activity.this, "Excellent! 이번 기회는 40번!", Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(Main2Activity.this, MainActivity.class);
                                startActivity(intent);

                            }
                        }
                        for (Main2Activity.CustomButton otherButton : CustomButtons) {
                            otherButton.turnFaceDown();
                        }
                    }
                    turnFaceUp();
                    playSound();
                    previousButton = Main2Activity.CustomButton.this;
                    ev.setText(String.valueOf(count));
                }
            };
            button.setOnClickListener(listener);
        };

        public ImageButton getButton() {
            return button;
        }

        public int getId() {
            return this.id;
        }

        public boolean equals(Main2Activity.CustomButton button) {
            return this.id == button.getId();

        }

        public void turnFaceUp() {
            this.button.setBackgroundResource(imageBackgroundSource);
        }

        public void turnFaceDown() {
            if (!this.matched)
                button.setBackgroundResource(R.drawable.icon2);
            else
                button.setVisibility(View.INVISIBLE);
        }

        public void setMatch() {
            this.matched = true;
        }

        public void playSound() {
            mp.start();
        }
    }

    public boolean onKeyDown(int keycode, KeyEvent event) {
        switch (keycode){
            case KeyEvent.KEYCODE_Q:
                CustomButtons.get(12).turnFaceUp();
                break;
            case KeyEvent.KEYCODE_R:
                CustomButtons.get(11).turnFaceUp();
                break;
            case KeyEvent.KEYCODE_T:
                CustomButtons.get(10).turnFaceUp();
                break;
            case KeyEvent.KEYCODE_U:
                CustomButtons.get(9).turnFaceUp();
                break;
                case KeyEvent.KEYCODE_8:
                    CustomButtons.get(8).turnFaceUp();
                break;
            case KeyEvent.KEYCODE_7:
                CustomButtons.get(7).turnFaceUp();
                break;
            case KeyEvent.KEYCODE_6:
                CustomButtons.get(6).turnFaceUp();
                break;
            case KeyEvent.KEYCODE_5:
                CustomButtons.get(5).turnFaceUp();
                break;
            case KeyEvent.KEYCODE_4:
                CustomButtons.get(4).turnFaceUp();
                break;
            case KeyEvent.KEYCODE_3:
                CustomButtons.get(3).turnFaceUp();
                break;
            case KeyEvent.KEYCODE_2:
                CustomButtons.get(2).turnFaceUp();
                break;
            case KeyEvent.KEYCODE_1:
                CustomButtons.get(1).turnFaceUp();
                break;
        }
        return false;
    }
}
