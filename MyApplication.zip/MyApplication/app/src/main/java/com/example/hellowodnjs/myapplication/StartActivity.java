package com.example.hellowodnjs.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import com.example.hellowodnjs.R;

public class StartActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);
    }
    public void onClick1(View v)
    {
        Intent intent = new Intent(StartActivity.this, Main3Activity.class);
        startActivity(intent);
        Toast.makeText(StartActivity.this, "기회는 20번 입니다 도저언~!", Toast.LENGTH_LONG).show();
    }
}
